from v1.uuid import gen_uuid
from v1.inf_get import get
from v1.typer import typer
from v1.form_typer import form_typer
#print("ts + True: "+gen_uuid("ts", True))
#print("ts + False: "+gen_uuid("ts", False))
#print("rd + True: "+gen_uuid("rd", True))
#print("rd + False: "+gen_uuid("rd", False))
正文 = form_typer(typer(get("abcdefghijkl", "utf-8", "utf-8", False, "", False, "", "", "", "international", ""), "abcdefghijk!"), "一言正文")
作者 = form_typer(typer(get("abcdefghijkl", "utf-8", "utf-8", False, "", False, "", "", "", "international", ""), "abcdefghijk!"), "一言的作者")
输出内容 = 正文+"   ——"+作者
print(输出内容)