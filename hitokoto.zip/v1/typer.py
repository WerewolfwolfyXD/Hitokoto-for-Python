
import json
import time
def typer(in_informations, compressorType):
    in_informations=json.loads(in_informations)
    #json_informations = type(json.loads(in_informations))
    o_uuid=in_informations["uuid"]
    o_id=in_informations["id"]
    o_hitokoto=in_informations["hitokoto"]
    o_type=in_informations["type"]
    o_from=in_informations["from"]
    o_from_who=in_informations["from_who"]
    o_creator=in_informations["creator"]
    o_creator_uid=in_informations["creator_uid"]
    o_reviewer=in_informations["reviewer"]
    o_commit_from=in_informations["commit_from"]
    o_created_at=in_informations["created_at"]
    o_length=in_informations['length']

    
    if compressorType=="":
        print("无处理格式，全部返回")
    else:
        l_compressorType = list(compressorType)
        if "a" in l_compressorType:
            out_id=o_id 
            c_out_id="一言标识："+str(out_id)
        else:
            out_id=""
            c_out_id=str(out_id)
        if "b" in l_compressorType:
            out_hitokoto=o_hitokoto
            c_out_hitokoto="一言正文："+str(out_hitokoto)
        else:
            out_hitokoto=""
            c_out_hitokoto=str(out_hitokoto)
        if "c" in l_compressorType:
            out_type=o_type 
            c_out_type="类型："+str(out_type)
        else:
            out_type=""
            c_out_type=str(out_type)
        if "c" in l_compressorType:
            out_from=o_from 
            c_out_from="一言的出处："+str(out_from)
        else:
            out_from=""
            c_out_from=str(out_from)
        if "d" in l_compressorType:
            out_from_who=o_from_who 
            c_out_from_who="一言的作者："+str(out_from_who)
        else:
            out_from_who=""
            c_out_from_who=str(out_from_who)
        if "e" in l_compressorType:
            out_creator=o_creator 
            c_out_creator="添加者："+str(out_creator)
        else:
            out_creator=""
            c_out_creator=str(out_creator)
        if "f" in l_compressorType:
            out_creator_uid=o_creator_uid 
            c_out_creator_uid="添加者用户标识："+str(out_creator_uid)
        else:
            out_creator_uid=""
            c_out_creator_uid=str(out_creator_uid)
        if "g" in l_compressorType:
            out_reviewer=o_reviewer 
            c_out_reviewer="审核员标识："+str(out_reviewer)
        else:
            out_reviewer=""
            c_out_reviewer=str(out_reviewer)
        if "h" in l_compressorType:
            out_uuid=o_uuid 
            c_out_uuid="一言唯一标识："+str(out_reviewer)
        else:
            out_uuid=""
            c_out_uuid=str(out_reviewer)
        if "i" in l_compressorType:
            out_commit_from=o_commit_from 
            c_out_commit_from="提交方式："+str(out_commit_from)
        else:
            out_commit_from=""
            c_out_commit_from=str(out_commit_from)
        if "j" in l_compressorType:
            out_created_at=o_created_at 
            c_out_created_at="添加时间："+str(out_created_at)
        else:
            out_created_at=""
            c_out_created_at=str(out_created_at)
        if "k" in l_compressorType:
            out_length=o_length 
            c_out_length="句子长度："+str(out_length)
        else:
            out_length=""
            c_out_length=str(out_length)
        #if "l" in l_compressorType:
        #z是文字，n是换行
        c_typed_data="{"+'"一言标识":'+'"'+out_id.__str__()+'", '+'"一言正文":'+'"'+out_hitokoto.__str__()+'", '+'"类型":'+'"'+out_type.__str__()+'", '+'"一言的出处":'+'"'+out_from.__str__()+'", '+'"一言的作者":'+'"'+out_from_who.__str__()+'", '+'"添加着":'+'"'+out_creator.__str__()+'", '+'"添加者用户标识":'+'"'+out_creator_uid.__str__()+'", '+'"审核员标识":'+'"'+out_reviewer.__str__()+'", '+'"一言唯一识别标识":'+'"'+out_uuid.__str__()+'", '+'"提交方式":'+'"'+out_commit_from.__str__()+'", '+'"添加时间":'+'"'+out_created_at.__str__()+'", '+'"句子长度":'+'"'+out_length.__str__()+'"}'
        if "!" in l_compressorType:
            return c_typed_data

        if "z" or "Z" in l_compressorType:
            if "n" or "N" in l_compressorType:
                typed_data=c_out_id+"\n"+c_out_hitokoto+"\n"+c_out_type+"\n"+c_out_from+"\n"+c_out_from_who+"\n"+c_out_creator+"\n"+c_out_creator_uid+"\n"+c_out_reviewer+"\n"+c_out_commit_from+"\n"+c_out_created_at+"\n"+c_out_length
                return typed_data
            else:
                typed_data=c_out_id+c_out_hitokoto+c_out_type+c_out_from+c_out_from_who+c_out_creator+c_out_creator_uid+c_out_reviewer+c_out_commit_from+c_out_created_at+c_out_length
                return typed_data
        else:
            if "n" or "N" in l_compressorType:
                typed_data=out_id+"\n"+out_hitokoto+"\n"+out_type+"\n"+out_from+"\n"+out_from_who+"\n"+out_creator+"\n"+out_creator_uid+"\n"+out_reviewer+"\n"+out_commit_from+"\n"+out_created_at+"\n"+out_length
                return typed_data
            else:    
                typed_data=out_id+out_hitokoto+out_type+out_from+out_from_who+out_creator+out_creator_uid+out_reviewer+out_commit_from+out_created_at+out_length
                return c_typed_data