
import json
import time
def form_typer(in_informations, get):
    in_informations = str(in_informations).replace("'", "")
    #print(in_informations)
    i_informations = json.loads(in_informations)
    #json_informations = type(json.loads(in_informations))
    typed_data=i_informations[get]
    return typed_data