# UUID module @BriTwilin Kanda
import uuid
def gen_uuid(subcommand, prst):
    if subcommand=="ts" or "timestamp":
        def_uid = str(uuid.uuid1())
        if prst==True:
            o_uuid = ''.join(def_uid.split('-'))
            return o_uuid
        else:
            return def_uid
    else:
        if subcommand=="rd" or "random":
            def_uid = str(uuid.uuid4())
            if prst==True:
                o_uuid = ''.join(def_uid.split('-'))
                return o_uuid
            else:
                return def_uid