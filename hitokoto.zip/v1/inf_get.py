import requests
def get(getType, getEncode, getCharset, callback_s, callback, select_s, select, min_lenght, max_lenght, getTunnel, headers_in):
    if headers_in=="":
        i_headers={
            'User-Agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Mobile Safari/537.36'
        }
    else:
        i_headers={
            headers_in
        }
    more_sel=False
    if getTunnel=="1" or "a" or "def" or "default" or True:
        req_url="https://v1.hitokoto.cn"
    if getTunnel=="2" or "b" or "int" or "international" or False:
        req_url="https://international.v1.hitokoto.cn"
    else:
        print("请求URL出现错误，将使用v1国内服务器")
        req_url="https://v1.hitokoto.cn"
    if getType=="":
        print("必须输入一个选项！获取参数不可为空！")
        exit(0)
    else:
        gl_x=len(str(getType))
        if str(gl_x)=="1":
            c_type=str(getType)    
        else: 
            more_sel=True   
            en_getType = "".join(str(getType).split("-"))
            en_getType_list = list(getType)
            c_type=en_getType_list
    if getEncode!="text" or "json" or "js":
        #print("未填写正确encode格式，将会返回格式化后的json文本！")
        encode_type="json"
    else:
        encode_type=str(getEncode)
    if getCharset!="utf-8" or "gbk":
        #print("未填写正确字符集参数，将会返回utf-8编码内容！")
        charset_type="utf-8"
    else:
        charset_type=str(getCharset)

    if callback_s==True:
        callback_type=str(callback)
    else:
        if callback_s==False:
            callback_type=""
        else:
            print("[err] 错误的callback函数调用！")
    if select_s==True:
        select_type=str(select)
    else:
        if select_s==False:
            select_type=""
        else:
            print("[err] 错误的callback函数调用！")
    if min_lenght=="":
        #print("未输入min_lenght，将返回默认值:0")
        min_lenght_type=""
    else:
        min_lenght_type=str(min_lenght)
    if max_lenght=="":
        #print("未输入max_lenght，将返回默认值:30")
        max_lenght_type=""
    else:
        max_lenght_type=str(max_lenght)

    req_param={
        "c":c_type,
        "encode":encode_type,
        "charset":charset_type,
        "callback":callback_type,
        "select":select_type,
        "min_lenght":min_lenght_type,
        "max_lenght":max_lenght_type
    }
    #print("url="+req_url.__str__()+" || params="+req_param.__str__()+" || headers="+i_headers.__str__())
    requests_callback = requests.get(url=req_url,params=req_param,headers=i_headers)
    forReturn = requests_callback.text
    return forReturn